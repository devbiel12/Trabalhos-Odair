/**
 * 
 */
package Pacman;

/**
 * Gabriel Araujo Farias
 */
public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Hello World");
		

	}

}
