/**
 * 
 */
package Pacman;

import java.util.Scanner;

/**
 * Autor Gabriel Araujo Farias
 * 01/04/2025
 */

public class BrincandoArray {
	public static int[] add(int[] array, int value){
        //System.out.println("teste");
        // cria o array maior que array
        int[] tempFahrenheit = new int[array.length + 1];

        for(int i = 0; i < array.length;i++){
            tempFahrenheit[i] = array[i];
        }
        tempArray[array.length] = value;
        return tempArray;
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float [] fahrenheit = {};
		Scanner in = new Scanner(System.in);
		boolean flag = true;
		while (flag){
			System.out.println("Digite uma temperatura em Fahrenheit");
			float fahUsuario = in.nextFloat();
			fahrenheit.add(fahrenheit,fahUsuario);
		}
		
		

	}

}
