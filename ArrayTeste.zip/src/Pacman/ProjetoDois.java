/**
 * 
 */
package Pacman;

import java.util.Scanner;

/**
 * 
 */
public class ProjetoDois {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Olá amigo!\nQual é o seu nome?");
		
		Scanner in = new Scanner(System.in);
		String name = in.nextLine();
		
		System.out.printf("Olá %s\n",name);

	}

}
